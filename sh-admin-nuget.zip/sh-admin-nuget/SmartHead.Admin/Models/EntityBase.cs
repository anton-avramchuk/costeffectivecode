﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace SmartHead.Admin.Models
{
    public abstract class EntityBase
    {
        [HiddenInput, Key]
        public virtual int Id { get; set; }

        public bool IsNew()
        {
            return Id == 0;
        }

        public PropertyInfo[] GetDependentProperties()
        {
            return  GetType().GetProperties().Where(p => typeof (EntityBase).IsAssignableFrom(p.PropertyType)).ToArray();
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != GetType()) return false;
            var eObj = ((EntityBase) obj);
            return !eObj.IsNew() && eObj.Id == Id;
        }

        public override int GetHashCode()
        {
            return IsNew() ? base.GetHashCode() : Id;
        }
    }
}