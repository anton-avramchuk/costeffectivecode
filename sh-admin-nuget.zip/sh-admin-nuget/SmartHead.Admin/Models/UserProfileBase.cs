﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SmartHead.Admin.Models
{
    [DisplayName("Пользователи")]
    public class UserProfileBase : EntityBase
    {
        [Required, DisplayName("Email")]
        public virtual string Email { get; set; }

        [Required]
        public virtual string UserName { get; set; }
    }
}
