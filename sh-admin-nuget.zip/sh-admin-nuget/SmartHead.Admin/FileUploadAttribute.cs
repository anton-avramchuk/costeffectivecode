﻿using System;

namespace SmartHead.Admin
{
    [AttributeUsage(AttributeTargets.Class)]
    public class FileUploadAttribute : Attribute
    {
    }
}
