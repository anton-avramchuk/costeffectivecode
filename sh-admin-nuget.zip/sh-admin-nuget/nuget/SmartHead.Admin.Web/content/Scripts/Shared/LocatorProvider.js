﻿function LocatorProvider() {
    this.locators = {};
    this.conventions = {
        'input[type="button"]': 'Button',
        button: 'Button',
        'input[type="text"]': 'TextBox',
        textarea: 'TextArea',
        form: 'Form',
        select: 'Dropdown'
    };
}

LocatorProvider.prototype.parseChildren = function (parent, deep) {
    if (parent instanceof Array) {
        for (var i = 0; i < parent.length; i++) {
            this.parseChildren(parent[i]);
        }
    }

    var me = this;
    var searchFunc = deep ? 'find' : 'children';
    $(parent)[searchFunc]('[id],[class]').each(function () {
        var that = $(this);
        var id = that.attr('id');
        if (!id) {
            var cssClass = that.attr('class');
        }
        
        var locator = id || cssClass.replace(' ', '_');
        locator += me.getConvention(that);
        me.locators[locator] = id ? '#' + id : '.' + cssClass.trim().replace(/\s+/, '.');
    });

    return this;
};

LocatorProvider.prototype.getConvention = function(element) {
    for (var i in this.conventions) {
        if (element.is(i)) {
            return this.conventions[i];
        }
    }

    return '';
};

LocatorProvider.prototype.getLocators = function() {
    return this.locators;
};