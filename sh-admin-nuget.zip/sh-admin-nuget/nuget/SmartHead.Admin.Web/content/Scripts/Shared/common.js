﻿// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function (from, to) {
    var rest = this.slice((to || from) + 1 || this.length);
    this.length = from < 0 ? this.length + from : from;
    return this.push.apply(this, rest);
};

// stupid IE7
if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (obj, start) {
        for (var i = (start || 0), j = this.length; i < j; i++) {
            if (this[i] === obj) {
                return i;
            }
        }
        return -1;
    };
}

if (!Array.prototype.forEach) {
    Array.prototype.forEach = function (fn, scope) {
        //'use strict';
        var i, len;
        for (i = 0, len = this.length; i < len; ++i) {
            if (i in this) {
                fn.call(scope, this[i], i, this);
            }
        }
    };
}

if ('function' !== typeof Array.prototype.reduce) {
    Array.prototype.reduce = function (callback, opt_initialValue) {
        //'use strict';
        if ('function' !== typeof callback) {
            throw new TypeError(callback + ' is not a function');
        }
        var index = 0, length = this.length >>> 0, value, isValueSet = false;
        if (1 < arguments.length) {
            value = opt_initialValue;
            isValueSet = true;
        }
        for (; length > index; ++index) {
            if (!this.hasOwnProperty(index)) continue;
            if (isValueSet) {
                value = callback(value, this[index], index, this);
            } else {
                value = this[index];
                isValueSet = true;
            }
        }
        if (!isValueSet) {
            throw new TypeError('Reduce of empty array with no initial value');
        }
        return value;
    };
}


Array.prototype.contains = function (val) {
    if (typeof (val) != 'function') {
        return this.indexOf(val) >= 0;
    }

    for (var i = 0; i < this.length; i++) {
        if (val(this[i])) {
            return true;
        }
    }

    return false;
};

Array.prototype.where = function (func) {
    var res = [];
    if (typeof (func) != 'function') throw 'func is not a function';
    for (var i = 0; i < this.length; i++) {
        if (func(this[i])) res.push(this[i]);
    }

    return res;
};

Array.prototype.select = function (func) {
    var res = [];
    if (typeof (func) != 'function') throw 'func is not a function';
    for (var i = 0; i < this.length; i++) {
        res.push(func(this[i]));
    }

    return res;
};

$(function () {
    $('.pagination li a').on('click', function (e) {
        var form = $('form#filter');
        if (form.size() > 0) {
            e.preventDefault();
            $('input[name="page"]').val($(this).data('page'));
            form.submit();
        }
    });
    
    $('.delete,.delete-button').click(function (e) {
        e.stopPropagation();
        return confirm('Вы уверены?');
    });

    $('table.index').find('td').click(function (e) {
        if(!$(e.currentTarget).is('td')) return false;
        var href = $(this).parent().find('.edit-link').attr('href');
        if (href) window.location.href = href;
        return false;
    });
});