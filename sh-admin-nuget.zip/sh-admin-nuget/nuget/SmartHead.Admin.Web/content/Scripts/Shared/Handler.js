﻿function Handler(locators) {
    this.locators = locators;
    this.initilized = false;
    this.init();
}

Handler.prototype.init = function () {
    if (!this.locators || this.initilized) return;

    for (var i in this) {
        if (typeof (this[i]) != 'function') continue;

        var parts = i.replace(/([A-Z]+)/g, " $1").replace(/([A-Z][a-z])/g, " $1").split(' ');
        var event = parts[parts.length - 1];
        var flag = parts[0];
        if (flag != 'on') continue;

        var locator = '';
        for (var j = 1; j < parts.length - 1; j++) {
            locator += parts[j];
        }

        locator = this.findLocator(locator);
        if (!locator || !event) continue;
        $(locator).bind(event.toLowerCase(), $.proxy(this[i], this));
    }

    this.initilized = true;
};

Handler.prototype.findLocator = function (locator) {
    if (!this.locators) return;
    locator = locator.toLowerCase();
    for (var i in this.locators) {
        if (locator == i.toLowerCase()) {
            return this.locators[i];
        }
    }
};

Handler.prototype.requireLocator = function (locator) {
    var el = $(this.locators[locator]);
    if (el.size() == 0) {
        throw 'DOM element with locator "' + locator + '" is not found';
    }

    return el;
};

Handler.prototype.getValue = function (locator) {
    var el = this.requireLocator(locator);
    return (el.is('[type="checkbox"]') || el.is('[type="radio"]'))
        ? el.is(':checked')
        : el.is('select') ? el.find('option:selected').val() : el.val();
};

Handler.prototype.setValue = function (locator, value) {
    this.requireLocator(locator).val(value);
};