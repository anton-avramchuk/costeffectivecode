﻿using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using SmartHead.Admin.Models;

namespace SmartHead.Admin.Web.Areas.Admin.Binders
{
    /// <summary>
    /// Binds Foreign Keys, using Db Context
    /// </summary>
    public class EntityModelBinder : DefaultModelBinder
    {
        public override object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var model = base.BindModel(controllerContext, bindingContext);
            if (!(model is EntityBase)) return null;

            var props = ((EntityBase) model).GetDependentProperties();

            var dbContext = DependencyResolver.Current.GetService<DbContext>();
            foreach (var propertyInfo in props)
            {
                var id = controllerContext.HttpContext.Request[propertyInfo.Name];
                if (string.IsNullOrEmpty(id)) continue;
                
                var fkValue = dbContext.Set(propertyInfo.PropertyType).Find(int.Parse(id));
                if (fkValue == null) continue;

                propertyInfo.SetValue(model, fkValue, null);
                if (bindingContext.ModelState[propertyInfo.Name].Errors.Any())
                {
                    bindingContext.ModelState[propertyInfo.Name].Errors.Clear();
                }
            }

            return model;
        }
    }
}