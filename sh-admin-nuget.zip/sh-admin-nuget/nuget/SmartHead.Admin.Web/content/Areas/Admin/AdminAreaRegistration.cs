﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using BootstrapSupport;
using NavigationRoutes;

// TODO: change Area namespace as R# suggests or it will not work properly
namespace System.Web.Areas.Admin
{
    [Obsolete("Change Area namespace as R# suggests or it will not work properly")]
    public class AdminAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Admin";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Admin_default",
                "Admin/{controller}/{action}/{id}",
                new { controller = "AdminHome", action = "Index", id = UrlParameter.Optional }
            );

            RegisterNamedRoutes(context.Routes);
            RegisterBundles(BundleTable.Bundles);
            RegisterIoc();
        }

        private static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/bootstrap").Include("~/Areas/Admin/Scripts/bootstrap*"));
            bundles.Add(new StyleBundle("~/Content/bootstrap").Include(
                "~/Areas/Admin/Content/bootstrap.css",
                "~/Areas/Admin/Content/bootstrap-responsive.css",
                "~/Areas/Admin/Content/admin.css"));

            bundles.Add(new ScriptBundle("~/js").Include(
                "~/Scripts/jquery-{version}.js",
                "~/Scripts/jquery-migrate-{version}.js",
                "~/Areas/Admin/Scripts/bootstrap.js",
                "~/Scripts/jquery.validate.js",
                "~/scripts/jquery.validate.unobtrusive.js",
                "~/Scripts/jquery.validate.unobtrusive-custom-for-bootstrap.js"
                ).IncludeDirectory("~/Scripts/Shared", "*.js"));

            bundles.Add(new StyleBundle("~/content/css").Include(
                "~/Areas/Admin/Content/bootstrap.css",
                "~/Areas/Admin/Content/bootstrap-responsive.css",
                "~/Areas/Admin/Content/bootstrap-mvc-validation.css"
                ));
        }

        private static void RegisterIoc()
        {
            var dr = DependencyResolver.Current;
            // TODO: register IOC here
        }

        /// <summary>
        /// Search for all controllers, derived from AdminControllerBase and add them to navigation, using DisplayName as a title
        /// For simplier mapping use <![CDATA[routes.MapNavigationRoute<CategoryController>("Categories", c => c.Index(1), AreaName)]]>
        /// </summary>
        /// <param name="routes"></param>
        private void RegisterNamedRoutes(RouteCollection routes)
        {

            var controllers = GetType().Assembly.GetTypes()
                .Where(t => t.BaseType != null && t.BaseType.Name == "AdminControllerBase`1" && !t.IsAbstract)
                .ToArray();

            var mapNavigationRoute = typeof(NavigationRouteConfigurationExtensions).GetMethods().Single(m => m.Name == "MapNavigationRoute" && m.IsGenericMethodDefinition);

            foreach (var controllerType in controllers)
            {
                var argument = controllerType.BaseType.GetGenericArguments()[0];
                var title = argument.AttributeExists<DisplayNameAttribute>()
                                ? argument.GetAttribute<DisplayNameAttribute>().DisplayName
                                : argument.Name;
                var methods = controllerType.GetMethods();
                Expression body = Expression.Call(
                    Expression.Parameter(controllerType),
                    methods.FirstOrDefault(m => m.Name == "Index") ?? methods.Single(m => m.ReturnType == typeof(ActionResult)),
                    Expression.Constant(1));

                var lamda = Expression.Lambda(
                    typeof(Func<,>).MakeGenericType(controllerType, typeof(ActionResult)),
                    body,
                    Expression.Parameter(controllerType));

                mapNavigationRoute.MakeGenericMethod(controllerType).Invoke(null, new object[] { routes, title, lamda, AreaName });
            }
        }
    }
}
