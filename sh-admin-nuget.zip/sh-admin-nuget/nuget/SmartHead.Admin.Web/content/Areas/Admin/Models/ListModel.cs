﻿using System.Collections.Generic;
using System.Linq;
using SmartHead.Admin.Models;

namespace System.Web.Mvc
{
    /// <summary>
    /// Generic list model
    /// </summary>
    public class ListModel<T> : IListModel<T> where T : EntityBase
	{
		public IEnumerable<T> List { get; set; }

		public int Count { get; set; }

		public int ItemOnPage { get; set; }

		public int Page { get; set; }

		public ListModel()
		{
			ItemOnPage = 20;
			Page = 1;
		}

        /// <exception cref="ArgumentException"></exception>
		public ListModel(IQueryable<T> query, int page = 1)
			: this()
		{
            if (page < 1)
            {
                throw new ArgumentException("Page must be >= 1", "page");
            }

            Page = page;
			
            List = ItemOnPage > 0
                ? query.OrderByDescending(e => e.Id).Skip((page - 1) * ItemOnPage).Take(ItemOnPage).ToList()
                : query.ToList();

		    Count = query.Count();
		}

        /// <exception cref="HttpException">404</exception>
        public void CheckPageExists()
        {
            if (Page > 1 && !List.Any())
            {
                throw new HttpException(404, "Not found");
            }
        }
	}
}