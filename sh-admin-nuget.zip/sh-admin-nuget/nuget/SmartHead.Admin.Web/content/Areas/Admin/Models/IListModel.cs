using System.Collections.Generic;

namespace System.Web.Mvc
{
    public interface IListModel
    {
        int Count { get; }

        int ItemOnPage { get; }

        int Page { get; }
    }

    public interface IListModel<out T> : IListModel
        where T : class
    {
        IEnumerable<T> List { get;  }
    }
}