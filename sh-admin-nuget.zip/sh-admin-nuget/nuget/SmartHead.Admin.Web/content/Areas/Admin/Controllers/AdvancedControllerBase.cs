﻿using BootstrapSupport;

namespace System.Web.Mvc
{
    public abstract class AdvancedControllerBase : Controller
    {
        #region Alerts

        public void Attention(string message)
        {
            TempData[Alerts.ATTENTION] = message;
        }

        public void Success(string message)
        {
            TempData[Alerts.SUCCESS] = message;
        }

        public void Information(string message)
        {
            TempData[Alerts.INFORMATION] = message;
        }

        public void Error(string message)
        {
            TempData[Alerts.ERROR] = message;
        }

        #endregion
    }
}