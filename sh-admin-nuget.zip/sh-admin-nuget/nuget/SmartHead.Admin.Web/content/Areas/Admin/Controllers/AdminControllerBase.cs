﻿using System;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SmartHead.Admin.Models;
using SmartHead.Web.Utils.Services;

namespace SmartHead.Admin.Web.Areas.Admin.Controllers
{
    [Authorize(Roles = "Admin")]
    public abstract class AdminControllerBase : AdvancedControllerBase
    {

    }

    public abstract class AdminControllerBase<T> : AdminControllerBase
         where T : EntityBase, new()
    {
        #region Vars

        protected readonly DbContext DbContext;

        #endregion

        #region Messages

        protected virtual string CreateMessage
        {
            get { return "Запись успешно создана"; }
        }

        protected virtual string EditMessage
        {
            get { return "Запись успешно отредактирована"; }
        }

        protected virtual string DeleteMessage
        {
            get { return "Запись успешно удалена"; }
        }

        #endregion

        protected AdminControllerBase(DbContext dbContext)
        {
            DbContext = dbContext;
        }

        #region Base Actions

        public virtual ActionResult Index([DefaultValue(1)] int page)
        {
            var model = GetListModel(page);
            model.CheckPageExists();

            return View(model);
        }

        public virtual ListModel<T> GetListModel(int page)
        {
            return new ListModel<T>(DbContext.Set<T>(), page);
        }

        public virtual ActionResult Create()
        {
            return View("Edit", new T());
        }

        [HttpPost]
        public virtual ActionResult Create(T model)
        {
            if (!ModelState.IsValid)
            {
                return View("Edit", model);
            }

            SaveModel(model);
            Success(CreateMessage);
            return RedirectToAction("Edit", new { id = model.Id });
        }

        protected virtual void UploadFiles(T model)
        {
            var fus = DependencyResolver.Current.GetService<IFileUploadService>();
            if (fus == null) throw new InvalidOperationException("IFileUploadService must be registered");

            if (!model.IsNew()) fus.DeletePreviouslyUploaded(GetEntity<T>(model.Id));
            fus.UploadAll(model);
        }


        protected virtual void SaveModel(T model)
        {
            if (model.GetType().IsDefined(typeof(FileUploadAttribute), true))
            {
                UploadFiles(model);
            }

            if (model.IsNew())
            {
                DbContext.Set<T>().Add(model);
            }
            else
            {
                var existing = GetEntity<T>(model.Id);
                DbContext.Entry(existing).CurrentValues.SetValues(model);
                foreach (var prop in model.GetDependentProperties())
                {
                    prop.SetValue(existing, prop.GetValue(model, null), null);
                }
            }

            DbContext.SaveChanges();
        }

        public virtual ActionResult Edit(int id)
        {
            var model = GetEntity(id);
            return View(model);
        }

        [HttpPost]
        public virtual ActionResult Edit(T model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            SaveModel(model);
            Success(EditMessage);
            return RedirectToAction("Edit", new { id = model.Id });
        }

        [HttpPost]
        public virtual ActionResult Delete(int id)
        {
            var dbset = DbContext.Set<T>();
            var model = GetEntity<T>(id);
            dbset.Remove(model);
            DbContext.SaveChanges();
            Success(DeleteMessage);
            return RedirectToAction("Index");
        }

        #endregion

        #region Helpers

        protected TE GetEntity<TE>(int id)
            where TE : EntityBase
        {
            var entity = DbContext.Set<TE>().SingleOrDefault(p => p.Id == id);
            if (entity == null)
            {
                throw new HttpException(404, string.Format("Entity with Id=\"{0}\" is not found", id));
            }

            return entity;
        }

        protected T GetEntity(int id)
        {
            return GetEntity<T>(id);
        }

        #endregion
    }
}
