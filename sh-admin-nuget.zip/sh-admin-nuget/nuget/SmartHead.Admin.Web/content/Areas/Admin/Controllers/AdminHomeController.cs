﻿using System.Web.Mvc;

namespace SmartHead.Admin.Web.content.Areas.Admin.Controllers
{
    public class AdminHomeController : Controller
    {
        //
        // GET: /AdminHome/

        public ActionResult Index()
        {
            return View();
        }

    }
}
