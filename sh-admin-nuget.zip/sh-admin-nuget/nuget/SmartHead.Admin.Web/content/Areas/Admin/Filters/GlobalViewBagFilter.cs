﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using SmartHead.Admin.Models;
using SmartHead.Admin.Web.Areas.Admin.Extensions;
using SmartHead.Web.Utils.Services;

namespace SmartHead.Admin.Web.Areas.Admin.Filters
{
    /// <summary>
    /// Sets usefull ViewBag properies, such as UploadDirHttPath
    /// </summary>
    public class GlobalViewBagFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.Controller.IsAdminCrudController())
            {
                SetupForeignKeys(filterContext);
            }

            var fus = DependencyResolver.Current.GetService<IFileUploadService>();
            filterContext.Controller.ViewBag.HttpUploadPath = fus == null ? string.Empty : fus.HttpPath;
        }

        private static void SetupForeignKeys(ActionExecutingContext filterContext)
        {
            var foreignKeys = filterContext.Controller.GetGenericType()
                                           .GetProperties()
                                           .Where(p => typeof(EntityBase).IsAssignableFrom(p.PropertyType))
                                           .ToArray();

            var dbContext = DependencyResolver.Current.GetService<DbContext>();
            foreach (var fk in foreignKeys)
            {
                var set = dbContext.Set(fk.PropertyType);
                set.Load();
                var res = new List<SelectListItem>();
                if (GetCustomAttributes(fk, typeof(RequiredAttribute), true).Length == 0)
                {
                    res.Add(new SelectListItem()
                    {
                        Text = "Нет",
                        Value = string.Empty
                    });
                }

                res.AddRange(from object entity in set.Local
                             select new SelectListItem()
                             {
                                 Text = entity.ToString(),
                                 Value = entity.GetType().GetProperty("Id").GetValue(entity, null).ToString()
                             });

                filterContext.Controller.ViewData[fk.Name] = res;
            }
        }
    }
}