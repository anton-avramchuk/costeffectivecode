﻿using System;
using System.Web.Mvc;

namespace SmartHead.Admin.Web.Areas.Admin.Extensions
{
    public static class ControllerExtensions
    {
        public static bool IsAdminCrudController(this IController controller)
        {
            var baseType = controller.GetType().BaseType;
            return baseType != null && baseType.Name == "AdminControllerBase`1";
        }

        public static Type GetGenericType(this IController controller)
        {
            if (!IsAdminCrudController(controller)) return null;
            return controller.GetType().BaseType.GetGenericArguments()[0];
        }
    }
}