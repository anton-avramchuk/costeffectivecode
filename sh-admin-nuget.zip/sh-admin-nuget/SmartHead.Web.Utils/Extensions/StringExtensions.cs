﻿namespace System.Web.Mvc
{
    public static class StringExtensions
    {
        public static string GetPreview(this string str, int symbols = 100)
        {
            return str.Length <= symbols
                       ? str
                       : str.Substring(0, symbols) + "...";
        }
    }
}
