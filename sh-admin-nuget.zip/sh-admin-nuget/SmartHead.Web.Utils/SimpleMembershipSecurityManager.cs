﻿using System;
using WebMatrix.WebData;

namespace SmartHead.Web.Utils
{
    public class SimpleMembershipSecurityManager
    {
        public int CurrentUserId { get { return WebSecurity.CurrentUserId; } }

        public string CurrentUserName { get { return WebSecurity.CurrentUserName; } }

        public bool HasUserId { get { return WebSecurity.HasUserId; } }

        public bool Initialized { get { return WebSecurity.Initialized; } }

        public bool IsAuthenticated { get { return WebSecurity.IsAuthenticated; } }

        public bool ChangePassword(string userName, string currentPassword, string newPassword)
        {
         WebSecurity.ChangePassword()   
        }

        public bool ConfirmAccount(string accountConfirmationToken);

        public bool ConfirmAccount(string userName, string accountConfirmationToken);

        public string CreateAccount(string userName, string password, bool requireConfirmationToken = false);

        public string CreateUserAndAccount(string userName, string password, object propertyValues = null, bool requireConfirmationToken = false);

        public string GeneratePasswordResetToken(string userName, int tokenExpirationInMinutesFromNow = 1440);

        public DateTime GetCreateDate(string userName);

        public DateTime GetLastPasswordFailureDate(string userName);

        public DateTime GetPasswordChangedDate(string userName);

        public int GetPasswordFailuresSinceLastSuccess(string userName);

        public int GetUserId(string userName);

        public int GetUserIdFromPasswordResetToken(string token);

        public void InitializeDatabaseConnection(string connectionStringName, string userTableName, string userIdColumn, string userNameColumn, bool autoCreateTables);

        public void InitializeDatabaseConnection(string connectionString, string providerName, string userTableName, string userIdColumn, string userNameColumn, bool autoCreateTables);

        public bool IsAccountLockedOut(string userName, int allowedPasswordAttempts, int intervalInSeconds);

        public bool IsAccountLockedOut(string userName, int allowedPasswordAttempts, TimeSpan interval);

        public bool IsConfirmed(string userName);

        public bool IsCurrentUser(string userName);

        public bool Login(string userName, string password, bool persistCookie = false);

        public void Logout();

        public void RequireAuthenticatedUser();

        public void RequireRoles(params string[] roles);

        public void RequireUser(int userId);

        public void RequireUser(string userName);

        public bool ResetPassword(string passwordResetToken, string newPassword);

        public bool UserExists(string userName);
    }
}
