﻿using System;
using System.IO;
using System.Web;

namespace SmartHead.Web.Utils.Services
{
    public class FileUploadService : FileUploadServiceBase
    {
        private readonly DirectoryInfo _uploadDir;

        public FileUploadService(string uploadDir, string httpPath)
        {
            HttpPath = httpPath;
            _uploadDir = new DirectoryInfo(uploadDir.StartsWith("~")
                ? HttpContext.Current.Server.MapPath(uploadDir)
                : uploadDir);
            if (!_uploadDir.Exists)
            {
                throw new ArgumentException(string.Format("uploadDir \"{0}\" doesn't exists", _uploadDir.FullName), "uploadDir");
            }
        }

        public override string UploadDir
        {
            get { return _uploadDir.FullName; }
        }

        public override string Upload(HttpPostedFileBase file)
        {
            var fn = GetUniqueFileName(CheckIsValid(file));
            file.SaveAs(Path.Combine(_uploadDir.FullName, fn));
            fn = HttpPath.EndsWith("/") ? HttpPath + fn : HttpPath + "/" + fn;
            return fn;
        }

        public override void DeleteFile(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return;
            fileName = fileName.StartsWith("~") 
                ? HttpContext.Current.Server.MapPath(fileName)
                : Path.Combine(_uploadDir.FullName, fileName);

            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }
        }

        public override string GetUniqueFileName(HttpPostedFileBase file)
        {
            return File.Exists(Path.Combine(_uploadDir.FullName, file.FileName))
                       ? string.Format("{0}{1}", Guid.NewGuid(), new FileInfo(file.FileName).Extension)
                       : file.FileName;
        }
    }
}
