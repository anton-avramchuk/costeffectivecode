﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Configuration;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;

namespace SmartHead.Web.Utils.Services
{
    /// <summary>
    /// Implementation of the <see cref="IMailService"/> interface.
    /// </summary>
    public class MailService : IMailService
    {
        #region Privates

        private readonly MailSettingsSectionGroup _settings;

        private String GetFrom()
        {
            var from = _settings.Smtp.From;
            if (String.IsNullOrEmpty(from))
            {
                from = "techsupport@smarthead.ru";
            }
            return from;
        }

        private void SendMessage(string to, string subject, string message, Stream attach, string attachName, string contentType, bool IsHtml)
        {
            var _msg = new MailMessage(GetFrom(), to, subject, message);
            _msg.BodyEncoding = Encoding.UTF8;
            _msg.IsBodyHtml = IsHtml;
            if (attach != null)
            {
                using (var _attach = new Attachment(attach, contentType))
                {
                    _attach.NameEncoding = Encoding.UTF8;
                    _attach.Name = attachName;
                
                
                    ContentDisposition disposition = _attach.ContentDisposition;
                    disposition.FileName = _attach.ContentType.Name;

                    _msg.Attachments.Add(_attach);
                }
            }

            var client = new SmtpClient();
            client.Send(_msg);
        }

        #endregion

        #region Ctor

        /// <summary>
        /// Initializes a new instance of the <see cref="MailService"/> class.
        /// </summary>
        /// <param name="mailSettings">The mail settings.</param>
        /// <example>
        /// Configuration configurationFile = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        /// MailSettingsSectionGroup mailSettings = (MailSettingsSectionGroup)configurationFile.GetSectionGroup("system.net/mailSettings");
        /// </example>
        public MailService(MailSettingsSectionGroup mailSettings)
        {
            _settings = mailSettings;
        }

        #endregion

        #region IMailService Members

        /// <summary>
        /// Sends the plain message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        public void SendPlainMessage(string email, string subject, string message)
        {
            SendMessage(email, subject, message, null, null, null, false);
        }

        /// <summary>
        /// Sends the plain message with attachment.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        /// <param name="attachment">The attachment.</param>
        /// <param name="attachmentName">Name of the attachment.</param>
        /// <param name="contentType">Type of the content.</param>
        public void SendPlainMessage(string email, string subject, string message, Stream attachment, string attachmentName, string contentType)
        {
            SendMessage(email, subject, message, attachment, attachmentName, contentType, false);
        }

        /// <summary>
        /// Sends the HTML message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        public void SendHtmlMessage(string email, string subject, string message)
        {
            SendMessage(email, subject, message, null, null, null, true);
        }

        /// <summary>
        /// Sends the HTML message with attachment.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        /// <param name="attachment">The attachment.</param>
        /// <param name="attachmentName">Name of the attachment.</param>
        /// <param name="contentType">Type of the content.</param>
        public void SendHtmlMessage(string email, string subject, string message, Stream attachment, string attachmentName, string contentType)
        {
            SendMessage(email, subject, message, attachment, attachmentName, contentType, true);
        }

        /// <summary>
        /// Sends the multipart message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="htmlMessage">The HTML body of message.</param>
        /// <param name="plainMessage">The plain body of message.</param>
        /// <param name="resources">The resources which should be attached to message.</param>
        public void SendMultipartMessage(string email, string subject, string htmlMessage, string plainMessage, IEnumerable<LinkedResource> resources)
        {
            var htmlView = AlternateView.CreateAlternateViewFromString(htmlMessage, Encoding.UTF8, "text/html");
            var plainView = AlternateView.CreateAlternateViewFromString(plainMessage, Encoding.UTF8, "text/plain");
            foreach (var r in resources)
            {
                htmlView.LinkedResources.Add(r);
            }
            var message = new MailMessage(GetFrom(), email) {Subject = subject};
            message.AlternateViews.Add(plainView);
            message.AlternateViews.Add(htmlView);
            var client = new SmtpClient();
            client.Send(message);
        }

        #endregion
    }
}
