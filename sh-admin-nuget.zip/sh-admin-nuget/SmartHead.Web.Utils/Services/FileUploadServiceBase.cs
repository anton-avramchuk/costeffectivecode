﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SmartHead.Web.Utils.Services
{
    public abstract class FileUploadServiceBase : IFileUploadService
    {
        public string HttpPath { get; protected set; }

        #region Abstract

        public abstract void DeleteFile(string fileName);

        public abstract string UploadDir { get; }

        public abstract string Upload(HttpPostedFileBase file);
        
        #endregion

        public virtual void DeletePreviouslyUploaded(object model)
        {
            var props = GetUploadableProperties(model);
            var keys = GetUploadedKeys(props);
            foreach (var key in keys)
            {
                HttpPostedFile file;
                if (CheckIsFileUplaoded(key, out file)) continue;

                var prop = props.Single(p => p.Name == key);
                var fileName = (string)prop.GetValue(model, null);
                if (string.IsNullOrEmpty(fileName)) continue;
                DeleteFile(fileName);
            }
        }

        public HttpPostedFileBase CheckIsValid(HttpPostedFileBase file)
        {
            if(file == null || file.ContentLength == 0) throw new ArgumentException("file");
            return file;
        }

        public virtual void UploadAll(object model)
        {
            var props = GetUploadableProperties(model);
            var keys = GetUploadedKeys(props);
            
            foreach (var key in keys)
            {
                HttpPostedFile file;
                if (CheckIsFileUplaoded(key, out file)) continue;

                var prop = props.Single(p => p.Name == key);
                prop.SetValue(
                    model,
                    Upload(new HttpPostedFileWrapper(file)),
                    null);      
            }
        }

        private static bool CheckIsFileUplaoded(string key, out HttpPostedFile file)
        {
            file = HttpContext.Current.Request.Files[key];
            if (file == null || file.ContentLength == 0) return true;
            return false;
        }

        #region Static Helpers

        protected static IEnumerable<string> GetUploadedKeys(IEnumerable<PropertyInfo> props)
        {
            var keys = HttpContext.Current.Request.Files.AllKeys.Where(k => props.Any(p => p.Name == k)).ToArray();
            return keys;
        }

        protected static PropertyInfo[] GetUploadableProperties(object model)
        {
            var props = model.GetType().GetProperties(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetField |
                BindingFlags.SetField).Where(p => p.PropertyType == typeof(string)).ToArray();
            return props;
        }

        public abstract string GetUniqueFileName(HttpPostedFileBase file);

        #endregion
    }
}