﻿using System.Web;

namespace SmartHead.Web.Utils.Services
{
    public interface IFileUploadService
    {
        /// <summary>
        /// Http Path to upload dir
        /// </summary>
        string HttpPath { get; }

        /// <summary>
        /// Full path to upload dir in file system
        /// </summary>
        string UploadDir { get; }

        /// <summary>
        /// Uploads file to upload dir
        /// </summary>
        /// <param name="file"></param>
        /// <returns>unique file name</returns>
        string Upload(HttpPostedFileBase file);

        /// <summary>
        /// Uploads all posted files, associated with model properies
        /// </summary>
        void UploadAll(object model);

        /// <summary>
        /// Deletes files, which properties have been uploaded this request
        /// </summary>
        /// <param name="model"></param>
        void DeletePreviouslyUploaded(object model);

        /// <summary>
        /// Gets unique file name for uploaded file
        /// </summary>
        /// <param name="file"></param>
        /// <returns>unique file name</returns>
        string GetUniqueFileName(HttpPostedFileBase file);
    }
}