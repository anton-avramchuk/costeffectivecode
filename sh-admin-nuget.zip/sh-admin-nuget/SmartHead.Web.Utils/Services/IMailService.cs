﻿using System.Collections.Generic;
using System.IO;
using System.Net.Mail;

namespace SmartHead.Web.Utils.Services
{
    /// <summary>
    /// Interface for service of the mail sending.
    /// <remarks>
    /// It's necessary to create the mail server's settings section in web.config file. 
    /// In this section the server's name or IP-address, port and user credentials should be placed.
    /// <para>
    /// These settings should be placed in section &lt;system.net&gt;.
    /// </para>
    /// </remarks>
    /// <example>
    /// &lt;mailSettings&gt;
    ///  &lt;smtp deliveryMethod="Network" from="name@domain.com"&gt;
    ///    &lt;network host="smtp.domain.com"
    ///                   userName="name"
    ///                   password="password" port="25"/&gt;
    ///  &lt;/smtp&gt;
    /// &lt;/mailSettings&gt;
    /// </example>
    /// </summary>
    public interface IMailService
    {
        /// <summary>
        /// Sends the plain message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        void SendPlainMessage(string email, string subject, string message);
        /// <summary>
        /// Sends the plain message with attachment.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        /// <param name="attachment">The attachment.</param>
        /// <param name="attachmentName">Name of the attachment.</param>
        /// <param name="contentType">Type of the content.</param>
        void SendPlainMessage(string email, string subject, string message, Stream attachment, string attachmentName, string contentType);
        /// <summary>
        /// Sends the HTML message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        void SendHtmlMessage(string email, string subject, string message);
        /// <summary>
        /// Sends the HTML message with attachment.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="message">The body of message.</param>
        /// <param name="attachment">The attachment.</param>
        /// <param name="attachmentName">Name of the attachment.</param>
        /// <param name="contentType">Type of the content.</param>
        void SendHtmlMessage(string email, string subject, string message, Stream attachment, string attachmentName, string contentType);
        /// <summary>
        /// Sends the multipart message.
        /// </summary>
        /// <param name="email">The email of the recipient.</param>
        /// <param name="subject">The subject of message.</param>
        /// <param name="htmlMessage">The HTML body of message.</param>
        /// <param name="plainMessage">The plain body of message.</param>
        /// <param name="resources">The resources which should be attached to message.</param>
        void SendMultipartMessage(string email, string subject, string htmlMessage, string plainMessage, IEnumerable<LinkedResource> resources);
    }
}
